# Trucking SaaS
This is an AI-powered trucking SaaS built with React and Firebase.
